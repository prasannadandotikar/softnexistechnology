// Code your testbench here
// or browse Examples
`timescale 1ns/1ps

module tb;

reg [3:0] A, B;
reg Cin;
wire [3:0] Sum;
wire Cout;

// Instantiate DUT (Device Under Test)
rca_4bit uut (
    .A(A),
    .B(B),
    .Cin(Cin),
    .Sum(Sum),
    .Cout(Cout)
);

// Dump file
initial begin
    $dumpfile("dump.vcd");
    $dumpvars(0, tb);
end

// Test cases
initial begin
    A = 4'b0000; B = 4'b0000; Cin = 0;
    #10;

    A = 4'b0011; B = 4'b0101; Cin = 0;
    #10;

    A = 4'b1111; B = 4'b0001; Cin = 0;
    #10;

    A = 4'b1010; B = 4'b0101; Cin = 1;
    #10;

    $finish;
end

endmodule